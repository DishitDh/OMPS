<?php 
$msg='';
if(isset($_POST['submit_review'])){
    //print_r($_POST);
    //echo "INSERT INTO `reviews` set `product_id`='".$_POST['id']."',`user_id`='".$_POST['user_id']."',  ,`rating`='".$_POST['rating']."',`comment`='".$_POST['comment']."'";exit;
    $qry = $conn->query("INSERT INTO `reviews` set `product_id`='".$_POST['id']."',`user_id`='".$_POST['user_id']."' ,`rating`='".$_POST['rating']."' ,`comment`='".$_POST['comment']."'");
    //header('location:'.$_SERVER['HTTP_REFERER'].'&msg=Review Added Successfully.');
    $msg = 'Review Added Successfully.';
}
if(isset($_GET['id'])){
    $qry = $conn->query("SELECT p.*, c.name as category FROM `product_list` p inner join category_list c on p.category_id =c.id where p.id = '{$_GET['id']}'");
    if($qry->num_rows > 0 ){
        foreach($qry->fetch_array() as $k => $v){
            if(!is_numeric($k))
            $$k = $v;
        }
        if(isset($user_id)){
            $qry2= $conn->query("SELECT *, CONCAT(lastname, ' ', firstname, ' ', COALESCE(middlename,'')) as `name` FROM `users` where id = '{$user_id}'");
            if($qry2->num_rows > 0){
                foreach($qry2->fetch_array() as $key => $val){
                    if(!is_numeric($key)){
                        $user[$key] = $val;
                    }
                }
            }
            $qry3= $conn->query("SELECT * FROM `seller_meta` where `user_id` = '{$user_id}'");
            if($qry3->num_rows > 0){
                while($row = $qry3->fetch_assoc()){
                        $user[$row['meta_field']] = $row['meta_value'];
                }
            }
        }
    }
}
//ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
//echo "SELECT u.*, r.*   FROM `reviews` r inner join users u on u.id =r.user_id where r.product_id = '{$_GET['id']}'";
$q  = $conn->query("SELECT u.*, r.*   FROM `reviews` r inner join users u on u.id =r.user_id where r.product_id = '{$_GET['id']}'");
$reviews=array();$alreadyReviewd = false;
while ($row = $q->fetch_array(MYSQLI_ASSOC)) {

//print_r($row);
    
    $reviews[] = $row;
    if(isset($_SESSION['userdata']['id']))
    if($row['user_id'] == $_SESSION['userdata']['id']){
        $alreadyReviewd = true;
    }
    
}
//echo '<pre>';
//print_r($reviews);
?>
<style>
    .product-thumbnail{
        width:20rem;
        height:20rem;
        object-fit: cover;
        object-position:center center
    }
</style>
<section class="py-4">
    <div class="container">
    <?php if(@$msg && !empty($msg)){?>
    <div class="alert alert-success ?> rounded-0 text-light py-1 px-4 mx-3">
            <div class="d-flex w-100 align-items-center">
                <div class="col-10"> <?PHP echo $msg;?> </div>
                <div class="col-2 text-end">
                    <button class="btn m-0 text-sm" type="button" onclick="$(this).closest('.alert').remove()"><i class="material-icons mb-0">close</i></button>
                </div>
            </div> 
        </div>
     <?PHP } ?>
    
         
   
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center mb-4">
                <img class="img-thumbnails border product-thumbnail" src="<?= validate_image((isset($id) && is_file(base_app."uploads/thumbnails/$id.png")) ? "uploads/thumbnails/$id.png?v=".(strtotime($date_updated)): "") ?>" alt="<?= isset($title) ? $title : "" ?>">
            </div>
        </div>
        <h3 class="text-center fw-bolder"><?= isset($title) ? $title : '' ?></h3>
        <center>
            <hr class="bg-primary opacity-100 w-25 mb-0" style="height:3px">
        </center>
        <div class="text-center"><small><?= isset($category) ? $category : '' ?></small></div>
        <p><?= isset($short_description) ? $short_description : "" ?></p>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-sm-12">
                <div class="d-flex w-100 align-items-center">
                    <div class="col-auto d-flex align-items-center pe-3">
                        <i class="material-icons me-3">inventory_2</i>
                        Stock/s:
                    </div>
                    <div class="col-auto flex-shrink-1 flex-grow-1"><?= isset($stock) ? number_format($stock) : 0 ?></div>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-sm-12">
                <div class="d-flex w-100 align-items-center">
                    <div class="col-auto d-flex align-items-center pe-3">
                        <i class="material-icons me-3">sell</i>
                        Price:
                    </div>
                    <div class="col-auto flex-shrink-1 flex-grow-1"><?= isset($selling_price) ? format_num($selling_price,2) : 0 ?></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <?= (isset($id) && is_file(base_app."contents/$id.html")) ? file_get_contents(base_app."contents/$id.html") : "" ?>
            </div>
        </div>
        <h3 class="text-center fw-bolder">User Information</h3>
        <center>
            <hr class="bg-primary opacity-100 w-25 mb-3" style="height:3px">
        </center>
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <dl>
                    <dt>
                        <div class="d-flex w-100 align-items-center">
                            <i class="material-icons me-2">person</i>
                            Name
                        </div>
                    </dt>
                    <dd class="ps-4"><?= isset($user['name']) ? $user['name'] : 'N/A' ?></dd>
                    <dt>
                        <div class="d-flex w-100 align-items-center">
                            <i class="material-icons me-2">email</i>
                            Email
                        </div>
                    </dt>
                    <dd class="ps-4"><?= isset($user['email']) ? '<a class="text-primary fw-bolder" href="mailto:'.$user['email'].'" target="_blank">'.$user['email'].'</a>' : 'N/A' ?></dd>
                    <dt>
                        <div class="d-flex w-100 align-items-center">
                            <i class="material-icons me-2">phone_enabled</i>
                            Contact #
                        </div>
                    </dt>
                    <dd class="ps-4"><?= isset($user['contact']) ? $user['contact'] : 'N/A' ?></dd>
                </dl>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <dl>
                    <dt>
                        <div class="d-flex w-100 align-items-center">
                            <i class="material-icons me-2">language</i>
                            Website
                        </div>
                    </dt>
                    <dd class="ps-4"><?= isset($user['website']) ? '<a class="text-primary fw-bolder" href="'.$user['website'].'" target="_blank">'.$user['website'].'</a>' : 'N/A' ?></dd>
                    <dt>
                        <div class="d-flex w-100 align-items-center">
                            <i class="fab fa-facebook-square me-2"></i>
                            Facebook Page Link
                        </div>
                    </dt>
                    <dd class="ps-4"><?= isset($user['fb_link']) ? '<a class="text-primary fw-bolder" href="'.$user['fb_link'].'" target="_blank">'.$user['fb_link'].'</a>' : 'N/A' ?></dd>
                </dl>
            </div>
             <h2>Reviews</h2>
            <?php 
            //print_r($_SESSION['id']);
            if (!empty($reviews)) : ?>
                <ul>
                    <?php foreach ($reviews as $review) : ?>
                        <li>
                            <p><strong>Rating:</strong> <?php echo $review['rating']; ?></p>
                            <p><strong>Comment:</strong> <?php echo $review['comment']; ?></p>
                            <p><strong>User:</strong> <?php echo $review['username']; ?></p>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else : ?>
                <p>No reviews for this product yet.</p>
                
            <?php endif; ?>
            <?php if(isset($_SESSION['userdata']) && !$alreadyReviewd){?>
             <form action="" id="review-form" method="post">
            <input type="hidden" name="id" value="<?= isset($_GET['id']) ? $_GET['id'] : '' ?>">
             <input type="hidden" name="user_id" value="<?= isset($_SESSION['userdata']['id']) ? $_SESSION['userdata']['id'] : '' ?>">
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12">
                     
                         <label for="rating">Rating:</label>
                            <select name="rating" id="rating" class="" required>
                                <option value="5">5 (Excellent)</option>
                                <option value="4">4 (Good)</option>
                                <option value="3">3 (Average)</option>
                                <option value="2">2 (Fair)</option>
                                <option value="1">1 (Poor)</option>
                            </select>
                        
                    </div>
                </div>
                
             
            </div>
            
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12">
                     
                         <label for="rating">Comment:</label>
                         <label for="short_description" class="form-label">Short Description</label>
                        <textarea name="comment" id="comment" cols="30" rows="3" class="form-control border rounded-0 px-2 py-1"><?= isset($comment) ? $comment : '' ?></textarea>
                        
                     
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 text-center">
                    <button type="submit" name="submit_review" class="btn bg-primary bg-gradient btn-sm text-light w-25"><span class="material-icons">save</span> Save</button>
            </div> </div>
            </form>
            <?PHP } ?>
        </div>
        <div class="text-end pt-3">
            <a href="./?page=products" class="btn btn-light border btn-sm"><span class="material-icons">arrow_back_ios</span> Back to List</a>
        </div>
    </div>
</section>
<script>
    $(function(){
        $('#delete_data').click(function(){
            _conf("Are you sure to delete this from list?","delete_product",['<?= isset($id) ? $id : '' ?>'])
        })
        $('#update_status').click(function(){
            uni_modal("Updating product Status", 'products/update_status.php?id=<?= isset($id) ? $id : '' ?>')
        })
    })
    function delete_product($id){
        start_loader();
        var _this = $(this)
        $('.err-msg').remove();
        var el = $('<div>')
        el.addClass("alert alert-danger err-msg")
        el.hide()
        $.ajax({
            url: '../classes/Master.php?f=delete_product',
            method: 'POST',
            data: {
                id: $id
            },
            dataType: 'json',
            error: err => {
                console.log(err)
                el.text('An error occurred.')
                el.show('slow')
                end_loader()
            },
            success: function(resp) {
                if (resp.status == 'success') {
                    location.replace('./?page=user')
                } else if (!!resp.msg) {
                    el.text('An error occurred.')
                    el.show('slow')
                } else {
                    el.text('An error occurred.')
                    el.show('slow')
                }
                end_loader()
            }
        })
    }
</script>                                                                                                                                              