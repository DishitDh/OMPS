<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Shopping Cart</h1>
        <?php 
		$userId =  $_SESSION['userdata']['id'];
if(isset($_GET['remove']) && $_GET['remove']==1)
removeCartItem($_GET['product_id'] , $userId);

function addProductToCart($userId, $productId, $quantity) {
    global $conn;
	$query = "select * from carts where user_id = $userId and product_id=$productId";
	$result = $conn->query($query);

	$cartItems = [];
	while ($row = $result->fetch_assoc()) {
		$cartItems[] = $row;
	}
	if($cartItems and !empty($cartItems))
		$query = "update carts set quantity = quantity+1 where user_id=$userId and product_id = $productId";
	else
		$query = "INSERT INTO carts (user_id, product_id, quantity) VALUES ($userId, $productId, $quantity)";
	//echo $query;
	return $conn->query($query);
}
if(!isset($_GET['remove']))
addProductToCart( $_SESSION['userdata']['id'], $_GET['product_id'] , 1);
 
 
 function removeCartItem($productId , $userId) {
			global $conn;
			$query = "delete from carts where product_id='$productId' and user_id='$userId'";
			$result = $conn->query($query);
			return ;
		}
function getCartItems($userId) {
	global $conn;
	$query = "SELECT carts.*, product_list.* FROM carts
			  JOIN product_list ON carts.product_id = product_list.id
			  WHERE carts.user_id = $userId";
	$result = $conn->query($query);

	$cartItems = [];
	while ($row = $result->fetch_assoc()) {
		$cartItems[] = $row;
	}

	return $cartItems;
}
		$userId = $_SESSION['userdata']['id'];
    	$cartItems = getCartItems($userId);
		if (!empty($cartItems)) : ?>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Product</th>
                        <th scope="col">Price</th>
                        <th scope="col">Quantity</th>
                         <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cartItems as $index => $item) : ?>
                        <tr>
                            <th scope="row"><?php echo $index + 1; ?></th>
                            <td><?php echo $item['title']; ?></td>
                            <td>$<?php echo $item['selling_price']; ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <TD>  <a href="?page=products/cart&remove=1&product_id=<?php echo $item['product_id']; ?>" class="btn btn-primary">Remove</a></TD>
                             <TD>  <a href="?page=products/cart&product_id=<?php echo $item['product_id']; ?>" class="btn btn-primary">Add One More</a></TD>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <a href="?page=products/checkout&product_id=<?php echo $item['product_id']; ?>" class="btn btn-primary">Proceed to Checkout</a>
             <A href=".?page=products" class="btn btn-primary"> Back to Market Place</A>
        <?php else : ?>
            <p>Your shopping cart is empty.</p>
            <A href=".?page=products" class="btn btn-primary"> Back to Market Place</A>
        <?php endif; ?>
    </div>
</body>
</html>