<?php
function getCartItems($userId) {
	global $conn;
	$query = "SELECT carts.*, product_list.* FROM carts
			  JOIN product_list ON carts.product_id = product_list.id
			  WHERE carts.user_id = $userId";
	$result = $conn->query($query);

	$cartItems = [];
	while ($row = $result->fetch_assoc()) {
		$cartItems[] = $row;
	}

	return $cartItems;
}
$userId = $_SESSION['userdata']['id'];
$cartItems = getCartItems($userId);
checkoutCart($userId , $cartItems);
function checkoutCart($userId, $cartItems) {
    global $conn;

    $conn->begin_transaction();

    try {
        // Update product stock quantity and create order records
        foreach ($cartItems as $item) {
            $productId = $item['id'];
            $quantity = $item['quantity'];

            // Check if there is sufficient stock
            $checkQuery = "SELECT stock FROM product_list WHERE id = $productId";
            $checkResult = $conn->query($checkQuery);

            if ($checkResult) {
                $stockQuantity = $checkResult->fetch_assoc()['stock'];

                if ($stockQuantity < $quantity) {
                    throw new Exception("Insufficient stock for product ID $productId");
                }
            } else {
                throw new Exception("Error checking stock for product ID $productId");
            }

            // Update product stock quantity
            $updateQuery = "UPDATE product_list SET stock = stock - $quantity WHERE id = $productId";
            $updateResult = $conn->query($updateQuery);

            if (!$updateResult) {
                throw new Exception("Error updating stock for product ID $productId");
            }

            // Create order record
            $orderQuery = "INSERT INTO orders (user_id, product_id, quantity) VALUES ($userId, $productId, $quantity)";
            $orderResult = $conn->query($orderQuery);

            if (!$orderResult) {
                throw new Exception("Error creating order for product ID $productId");
            }
        }

        // Clear user's cart
        $clearCartQuery = "DELETE FROM carts WHERE user_id = $userId";
        $clearCartResult = $conn->query($clearCartQuery);

        if (!$clearCartResult) {
            throw new Exception("Error clearing user's cart");
        }

        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        return false;
    }
}
?>
<section class="py-4">
    <div class="container">
    <div class="row">
        <h3 class="text-center fw-bolder">Checkout</h3>
        </div>
    
    <div class="alert alert-success ?> rounded-0 text-light py-1 px-4 mx-3">
            <div class="d-flex w-100 align-items-center">
                <div class="col-10"> Checkout successfull. </div>
                <div class="col-2 text-end">
                    <button class="btn m-0 text-sm" type="button" onclick="$(this).closest('.alert').remove()"><i class="material-icons mb-0">close</i></button>
                </div>
            </div> 
        </div>
     
    
  </div>
  </section> 
   
        
        